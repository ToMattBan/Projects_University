﻿function Parcelamento() {
  var npar = parseInt(document.getElementById('npar').value);
  var dateBase = new Date(document.getElementById('dateBase').value);
  var tempParc = parseInt(document.getElementById('tempParc').value);
  var parcelas = "";



  // var teste = new Date(document.getElementById('dateBase').value);
  // teste.setDate(teste.getDate() + 30);

  dateBase.setDate(dateBase.getDate() + (tempParc + 1), 'days')
  if (dateBase.getDay() == 0) {
    dateBase.setDate(dateBase.getDate() + 1, 'days')
  }
  if (dateBase.getDay() == 6) {
    dateBase.setDate(dateBase.getDate() + 2, 'days')
  }
  for (var x = 1; x <= npar; x++) {
    parcelas += x + "º Parcela » " + ("0" + dateBase.getDate()).slice(-2) + "/" + ("0" + (dateBase.getMonth() + 1)).slice(-2) + "/" + dateBase.getFullYear() + "\n" + "\n";
    dateBase.setDate(dateBase.getDate() + (tempParc), 'days')
    if (dateBase.getDay() == 0) {
      dateBase.setDate(dateBase.getDate() + 1, 'days')
    }
    if (dateBase.getDay() == 6) {
      dateBase.setDate(dateBase.getDate() + 2, 'days')
    }
  }




  document.getElementById('parcelas').innerText = parcelas;
};